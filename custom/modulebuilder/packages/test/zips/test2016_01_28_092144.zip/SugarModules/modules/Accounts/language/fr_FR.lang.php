<?php 
 // created: 2016-01-28 09:21:43
$mod_strings['LBL_CP'] = 'Cp';
$mod_strings['LBL_RAISON_SOCIALE'] = 'Raison sociale';
$mod_strings['LBL_RESPONSABLE'] = 'Responsable';
$mod_strings['LBL_LIBELLE_INTERNE'] = 'libelle interne';
$mod_strings['LBL_TELEPHONE'] = 'Telephone';
$mod_strings['LBL_PORTABLE'] = 'Portable';
$mod_strings['LBL_FAX'] = 'Fax';
$mod_strings['LBL_MAIL'] = 'Mail';
$mod_strings['LBL_ADRESSE'] = 'Adresse';
$mod_strings['LBL_VILLE'] = 'Ville';
$mod_strings['LBL_SIGLE'] = 'Sigle';
$mod_strings['LBL_ECHEANCE'] = 'Echeance';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Lims';
$mod_strings['LBL_NAME'] = 'Nom :';

?>
