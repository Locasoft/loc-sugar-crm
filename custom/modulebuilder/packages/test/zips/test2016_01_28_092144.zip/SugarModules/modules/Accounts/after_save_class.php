<?php

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class after_save_class
{
    function after_save_method($bean, $event, $arguments)
    {

        $input = $bean;

        $ch = curl_init("http://localhost:8085/client");

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($input));
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

        // Download the given URL, and return output
        $output = curl_exec($ch);

        // Close the cURL resource, and free system resources
        curl_close($ch);
        error_log($input, 3, "testtt.log");




    }
}

?>