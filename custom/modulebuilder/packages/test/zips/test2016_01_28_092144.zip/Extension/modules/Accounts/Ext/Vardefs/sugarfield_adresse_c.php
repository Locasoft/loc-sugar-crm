<?php
 // created: 2016-01-28 09:17:09
$dictionary['Account']['fields']['adresse_c']['labelValue']='Adresse';

 ?>