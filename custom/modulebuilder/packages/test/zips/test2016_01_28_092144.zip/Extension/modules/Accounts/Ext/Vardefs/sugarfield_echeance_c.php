<?php
 // created: 2016-01-28 09:17:37
$dictionary['Account']['fields']['echeance_c']['labelValue']='Echeance';

 ?>