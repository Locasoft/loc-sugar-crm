<?php
 // created: 2016-01-28 09:17:03
$dictionary['Account']['fields']['mail_c']['labelValue']='Mail';

 ?>