<?php
 // created: 2016-01-28 09:17:28
$dictionary['Account']['fields']['sigle_c']['labelValue']='Sigle';

 ?>