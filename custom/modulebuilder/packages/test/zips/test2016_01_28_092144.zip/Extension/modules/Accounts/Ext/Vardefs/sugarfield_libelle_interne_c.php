<?php
 // created: 2016-01-28 09:15:50
$dictionary['Account']['fields']['libelle_interne_c']['labelValue']='libelle interne';

 ?>