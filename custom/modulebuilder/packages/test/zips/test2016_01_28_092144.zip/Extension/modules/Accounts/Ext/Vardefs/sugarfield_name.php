<?php
 // created: 2016-01-28 09:19:37
$dictionary['Account']['fields']['name']['required']=false;
$dictionary['Account']['fields']['name']['comments']='Name of the Company';
$dictionary['Account']['fields']['name']['merge_filter']='disabled';

 ?>