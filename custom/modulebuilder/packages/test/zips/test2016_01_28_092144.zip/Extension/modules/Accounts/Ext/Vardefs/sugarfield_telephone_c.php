<?php
 // created: 2016-01-28 09:16:01
$dictionary['Account']['fields']['telephone_c']['labelValue']='Telephone';

 ?>