<?php
 // created: 2016-01-28 09:15:41
$dictionary['Account']['fields']['responsable_c']['labelValue']='Responsable';

 ?>