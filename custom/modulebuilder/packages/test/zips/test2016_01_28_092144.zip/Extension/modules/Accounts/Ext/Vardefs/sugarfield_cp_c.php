<?php
 // created: 2016-01-28 09:13:08
$dictionary['Account']['fields']['cp_c']['labelValue']='Cp';

 ?>