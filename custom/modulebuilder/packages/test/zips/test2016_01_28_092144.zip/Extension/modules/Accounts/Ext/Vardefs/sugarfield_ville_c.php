<?php
 // created: 2016-01-28 09:17:15
$dictionary['Account']['fields']['ville_c']['labelValue']='Ville';

 ?>