<?php
 // created: 2016-01-28 09:19:49
$dictionary['Account']['fields']['raison_sociale_c']['labelValue']='Raison sociale';

 ?>