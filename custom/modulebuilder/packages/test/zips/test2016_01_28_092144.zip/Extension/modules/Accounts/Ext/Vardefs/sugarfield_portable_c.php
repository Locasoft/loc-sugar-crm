<?php
 // created: 2016-01-28 09:16:06
$dictionary['Account']['fields']['portable_c']['labelValue']='Portable';

 ?>