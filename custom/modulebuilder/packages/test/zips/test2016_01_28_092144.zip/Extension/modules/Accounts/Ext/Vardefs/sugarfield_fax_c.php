<?php
 // created: 2016-01-28 09:16:12
$dictionary['Account']['fields']['fax_c']['labelValue']='Fax';

 ?>