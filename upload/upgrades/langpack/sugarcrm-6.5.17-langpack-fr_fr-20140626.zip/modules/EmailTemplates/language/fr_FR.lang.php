<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


/*********************************************************************************
 * SugarCRM is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2010 SugarCRM Inc.
 * 
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU Affero General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 * 
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 * 
 * Contributor(s): www.synolia.com - sugar@synolia.com
 * You can contact SYNOLIA at 51 avenue Jean Jaures 69007 - LYON FRANCE
 * or at email address contact@synolia.com.
 ********************************************************************************/














$mod_strings = array (
  'LBL_ACCOUNT' => 'Compte',
  'LBL_ACTIVITIES_REPORTS' => 'Rapport d&#39;activités',
  'LBL_ADD_ANOTHER_FILE' => 'Ajouter un autre fichier',
  'LBL_ADD_DOCUMENT' => 'Ajouter un Document Sugar',
  'LBL_ADD_FILE' => 'Ajouter Fichier',
  'LBL_ASSIGNED_TO_ID' => 'Assigné à',
  'LBL_ATTACHMENTS' => 'Pièce(s)&nbsp;jointe(s)',
  'LBL_BASE_MODULE' => 'Module de base',
  'LBL_BODY' => 'Corps:',
  'LBL_CLOSE' => 'Clos:',
  'LBL_COLON' => ':',
  'LBL_CREATED_BY' => 'Créé par',
  'LBL_DESCRIPTION' => 'Description:',
  'LBL_EDIT_ALT_TEXT' => 'Editer le texte Alternatif',
  'LBL_EDIT_LAYOUT' => 'Editer la mise en page',
  'LBL_EMAIL_ATTACHMENT' => 'Pièce jointe',
  'LBL_FROM_ADDRESS' => 'De (Adresse)',
  'LBL_FROM_NAME' => 'De (Nom)',
  'LBL_HIDE_ALT_TEXT' => 'Masquer le texte alternatif',
  'LBL_HTML_BODY' => 'Corps HTML',
  'LBL_ID_FF_CLEAR' => 'Vider',
  'LBL_INSERT' => 'Insérer',
  'LBL_INSERT_TRACKER_URL' => 'Insérer URL tracker:',
  'LBL_INSERT_URL_REF' => 'Insérer URL référence',
  'LBL_INSERT_VARIABLE' => 'Insérer variable:',
  'LBL_LIST_BASE_MODULE' => 'Module de base:',
  'LBL_LIST_DATE_MODIFIED' => 'Date de modification',
  'LBL_LIST_DESCRIPTION' => 'Description',
  'LBL_LIST_FORM_TITLE' => 'Liste des Modèles',
  'LBL_LIST_NAME' => 'Nom',
  'LBL_MODULE_NAME' => 'Modèle d&#39;email',
  'LBL_MODULE_NAME_SINGULAR' => 'Modèle Email',
  'LBL_MODULE_NAME_SINGULAR_WORKFLOW' => 'Modèle Email pour les Workflows',
  'LBL_MODULE_NAME_WORKFLOW' => 'Modèles pour le Workflow Email',
  'LBL_MODULE_TITLE' => 'Modèles Emails',
  'LBL_NAME' => 'Nom:',
  'LBL_NEW' => 'Nouveau',
  'LBL_NEW_FORM_TITLE' => 'Nouveau Modèle Email',
  'LBL_PLAIN_TEXT' => 'Texte brut',
  'LBL_PUBLISH' => 'Publier:',
  'LBL_PUBLISHED' => 'Publié',
  'LBL_RELATED_TO' => 'Lié à:',
  'LBL_SEARCH_FORM_TITLE' => 'Rechercher un Modèle',
  'LBL_SELECT' => 'Sélectionner',
  'LBL_SEND_AS_TEXT' => 'Envoyer en texte brut',
  'LBL_SHOW_ALT_TEXT' => 'Afficher le texte Alternatif',
  'LBL_SUBJECT' => 'Sujet:',
  'LBL_SUGAR_DOCUMENT' => 'Document Sugar',
  'LBL_TEAMS' => 'Equipes:',
  'LBL_TEAMS_LINK' => 'Equipes',
  'LBL_TEXT_BODY' => 'Corps Texte',
  'LBL_TEXT_ONLY' => 'Texte brut',
  'LBL_TYPE' => 'Type',
  'LBL_USERS' => 'Utilisateurs',
  'LNK_ALL_EMAIL_LIST' => 'Tous les Emails',
  'LNK_ARCHIVED_EMAIL_LIST' => 'Emails archivés',
  'LNK_CHECK_EMAIL' => 'Relever les Mails',
  'LNK_CHECK_MY_INBOX' => 'Vérifier Mes Emails',
  'LNK_DRAFTS_EMAIL_LIST' => 'Tous les Brouillons',
  'LNK_EMAIL_TEMPLATE_LIST' => 'Modèles d&#39;email',
  'LNK_GROUP_INBOX' => 'Emails Groupés',
  'LNK_IMPORT_NOTES' => 'Import Notes',
  'LNK_MY_ARCHIVED_LIST' => 'Mes Archives',
  'LNK_MY_DRAFTS' => 'Mes Brouillons',
  'LNK_MY_INBOX' => 'Mes Emails',
  'LNK_NEW_ARCHIVE_EMAIL' => 'Nouvel Email Archivé',
  'LNK_NEW_EMAIL' => 'Archiver Email',
  'LNK_NEW_EMAIL_TEMPLATE' => 'Nouveau Modèle d&#39;email',
  'LNK_NEW_SEND_EMAIL' => 'Envoyer un Email',
  'LNK_SENT_EMAIL_LIST' => 'Emails Envoyés',
  'LNK_VIEW_CALENDAR' => 'Aujourd&#39;hui',
  'LNK_VIEW_MY_INBOX' => 'Mes Emails',
);

